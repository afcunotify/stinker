<h2 align="center">Stink</h2>

<div align="center">
 <img alt="GitHub Repo stars" src="https://img.shields.io/github/stars/FallenAstaroth/stink?color=%23c39010">
 <img alt="GitHub release (latest by date)" src="https://img.shields.io/github/v/release/FallenAstaroth/stink">
 <img alt="Python Version" src="https://img.shields.io/badge/python-3.7%20%7C%203.8%20%7C%203.9%20%7C%203.10%20%7C%203.11-blue">
 <img alt="GitHub" src="https://img.shields.io/github/license/FallenAstaroth/stink?color=%231a993e">
</div>
<div align="center">
 <br>
 <img alt="Logo" src="docs/logo.jpg">
</div>
<p align="center"><br>The code is for information purposes only. The author is not responsible for its use.<p>
<h3 align="center">Introduction</h3>
<p align="center">
  <a href="docs/ua.md"><img src="docs/ua_icon.svg" width="70"></a>
  <a>&#8192;&#8192;</a>
  <a href="docs/ru.md"><img src="docs/ru_icon.svg" width="70"></a>
  <a>&#8192;&#8192;</a>
  <a href="docs/en.md"><img src="docs/en_icon.svg" width="70"></a>
</p>
