from enum import Enum


class Utils(Enum):
    autostart = "Autostart"
    message = "Message"
    all = "All"
